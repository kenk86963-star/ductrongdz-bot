const { Client, GatewayIntentBits, REST, Routes, SlashCommandBuilder } = require("discord.js");

const TOKEN = process.env.DISCORD_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;

if (!TOKEN || !CLIENT_ID) {
  console.error("Missing DISCORD_TOKEN or CLIENT_ID in environment variables.");
  process.exit(1);
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds]
});

const commands = [
  new SlashCommandBuilder()
    .setName("getkey")
    .setDescription("Nhận link nhiệm vụ để lấy KEY")
].map(command => command.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  await rest.put(
    Routes.applicationCommands(CLIENT_ID),
    { body: commands }
  );
  console.log("Đã đăng ký /getkey");
}

client.once("ready", () => {
  console.log(`Bot online: ${client.user.tag}`);
});

client.on("interactionCreate", async interaction => {
  if (!interaction.isChatInputCommand()) return;

  if (interaction.commandName === "getkey") {
    await interaction.reply({
      content:
        "🎁 **LẤY KEY**\n\n" +
        "🔗 Link nhiệm vụ: https://example.com/task\n\n" +
        "Sau khi hệ thống xác nhận hoàn thành, bot sẽ cấp KEY cho bạn.",
      ephemeral: true
    });
  }
});

registerCommands()
  .then(() => client.login(TOKEN))
  .catch(error => {
    console.error("Không thể khởi động bot:", error);
    process.exit(1);
  });
