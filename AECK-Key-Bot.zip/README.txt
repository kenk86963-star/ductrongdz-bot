AECK KEY BOT

Biến môi trường cần tạo:
DISCORD_TOKEN = Token bot Discord
CLIENT_ID = Application ID của bot

Chạy:
npm install
npm start

Lưu ý:
- Không đưa DISCORD_TOKEN cho người khác.
- Link example.com/task chỉ là link mẫu; sau này thay bằng hệ thống nhiệm vụ/API hợp lệ của bạn.
